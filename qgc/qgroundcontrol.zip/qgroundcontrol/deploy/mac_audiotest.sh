#!/bin/sh
cp -r audio bin/mac/qgroundcontrol.app/Contents/MacOs/.
