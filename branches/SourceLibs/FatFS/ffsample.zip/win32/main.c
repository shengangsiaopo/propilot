/*------------------------------------------------------------------------/
/  The Main Development Bench of FatFs Module 
/-------------------------------------------------------------------------/
/
/  Copyright (C) 2010, ChaN, all right reserved.
/
/ * This software is a free software and there is NO WARRANTY.
/ * No restriction on use. You can use, modify and redistribute it for
/   personal, non-profit or commercial products UNDER YOUR RESPONSIBILITY.
/ * Redistributions of source code must retain the above copyright notice.
/
/-------------------------------------------------------------------------*/


#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include "diskio.h"
#include "ff.h"


#define PHY_DRV_START	1	/* Physical drive# on the Windows mapped as drive 0 */
#define PHY_DRV_END		8	/* Last physical drives to be mapped */


#ifdef UNICODE
#if !_LFN_UNICODE
#error Configuration mismatch. _LFN_UNICODE must be 1.
#endif
#else
#if _LFN_UNICODE
#error Configuration mismatch. _LFN_UNICODE must be 0.
#endif
#endif



#if _MULTI_PARTITION	/* Volume - Partition resolution table */
const PARTITION Drives[] = {
	{0, 0},	/* Logical Drive 0 <== Physical Drive 0, Partition 0 */
	{0, 1},	/* Logical Drive 1 <== Physical Drive 0, Partition 1 */
	{1, 0}	/* Logical Drive 2 <== Physical Drive 1, Partition 0 */
};
#endif


/*---------------------------------------------------------*/
/* Work Area                                               */
/*---------------------------------------------------------*/


LONGLONG acc_size;			/* Work register for scan_files() */
WORD acc_files, acc_dirs;
FILINFO Finfo;
#if _USE_LFN
TCHAR Lfname[256];
#endif

TCHAR Line[300];			/* Console input/output buffer */
HANDLE hCon, hKey;

FATFS FatFs[_DRIVES];		/* File system object for logical drive */
BYTE Buff[32768];			/* Working buffer */

#if _USE_FASTSEEK
DWORD seektbl[128];
#endif


/*---------------------------------------------------------*/
/* User Provided RTC Function for FatFs module             */
/*---------------------------------------------------------*/
/* This is a real time clock service to be called from     */
/* FatFs module. Any valid time must be returned even if   */
/* the system does not support an RTC.                     */
/* This function is not required in read-only cfg.         */

DWORD get_fattime (void)
{
	SYSTEMTIME tm;

	/* Get local time */
	GetLocalTime(&tm);

	/* Pack date and time into a DWORD variable */
	return 	  ((DWORD)(tm.wYear - 1980) << 25)
			| ((DWORD)tm.wMonth << 21)
			| ((DWORD)tm.wDay << 16)
			| (WORD)(tm.wHour << 11)
			| (WORD)(tm.wMinute << 5)
			| (WORD)(tm.wSecond >> 1);
}



/*--------------------------------------------------------------------------*/
/* Monitor                                                                  */

/*----------------------------------------------*/
/* Get a value of the string                    */
/*----------------------------------------------*/
/*	"123 -5   0x3ff 0b1111 0377  w "
	    ^                           1st call returns 123 and next ptr
	       ^                        2nd call returns -5 and next ptr
                   ^                3rd call returns 1023 and next ptr
                          ^         4th call returns 15 and next ptr
                               ^    5th call returns 255 and next ptr
                                  ^ 6th call fails and returns 0
*/

int xatoi (			/* 0:Failed, 1:Successful */
	TCHAR **str,	/* Pointer to pointer to the string */
	long *res		/* Pointer to a valiable to store the value */
)
{
	unsigned long val;
	unsigned char r, s = 0;
	TCHAR c;


	*res = 0;
	while ((c = **str) == ' ') (*str)++;	/* Skip leading spaces */

	if (c == '-') {		/* negative? */
		s = 1;
		c = *(++(*str));
	}

	if (c == '0') {
		c = *(++(*str));
		switch (c) {
		case 'x':		/* hexdecimal */
			r = 16; c = *(++(*str));
			break;
		case 'b':		/* binary */
			r = 2; c = *(++(*str));
			break;
		default:
			if (c <= ' ') return 1;	/* single zero */
			if (c < '0' || c > '9') return 0;	/* invalid char */
			r = 8;		/* octal */
		}
	} else {
		if (c < '0' || c > '9') return 0;	/* EOL or invalid char */
		r = 10;			/* decimal */
	}

	val = 0;
	while (c > ' ') {
		if (c >= 'a') c -= 0x20;
		c -= '0';
		if (c >= 17) {
			c -= 7;
			if (c <= 9) return 0;	/* invalid char */
		}
		if (c >= r) return 0;		/* invalid char for current radix */
		val = val * r + c;
		c = *(++(*str));
	}
	if (s) val = 0 - val;			/* apply sign if needed */

	*res = val;
	return 1;
}


/*----------------------------------------------*/
/* Dump a block of byte array                   */

void put_dump (
	const unsigned char* buff,	/* Pointer to the byte array to be dumped */
	unsigned long addr,			/* Heading address value */
	int cnt						/* Number of bytes to be dumped */
)
{
	int i;


	_tprintf(_T("%08lX "), addr);

	for (i = 0; i < cnt; i++)
		_tprintf(_T(" %02X"), buff[i]);

	_puttchar(' ');
	for (i = 0; i < cnt; i++)
		_puttchar((TCHAR)((buff[i] >= ' ' && buff[i] <= '~') ? buff[i] : '.'));

	_puttchar('\n');
}



FRESULT scan_files (
	TCHAR* path		/* Pointer to the path name working buffer */
)
{
	DIR dirs;
	FRESULT res;
	int i;
	TCHAR *fn;


	if ((res = f_opendir(&dirs, path)) == FR_OK) {
		i = _tcslen(path);
		while (((res = f_readdir(&dirs, &Finfo)) == FR_OK) && Finfo.fname[0]) {
			if (_FS_RPATH && Finfo.fname[0] == '.') continue;
#if _USE_LFN
			fn = *Finfo.lfname ? Finfo.lfname : Finfo.fname;
#else
			fn = Finfo.fname;
#endif
			if (Finfo.fattrib & AM_DIR) {
				acc_dirs++;
				*(path+i) = '/'; _tcscpy(path+i+1, fn);
				res = scan_files(path);
				*(path+i) = '\0';
				if (res != FR_OK) break;
			} else {
//				_tprintf(_T("%s/%s\n"), path, fn);
				acc_files++;
				acc_size += Finfo.fsize;
			}
		}
	}

	return res;
}



void put_rc (FRESULT rc)
{
	const TCHAR *p =
		_T("OK\0DISK_ERR\0INT_ERR\0NOT_READY\0NO_FILE\0NO_PATH\0INVALID_NAME\0")
		_T("DENIED\0EXIST\0INVALID_OBJECT\0WRITE_PROTECTED\0INVALID_DRIVE\0")
		_T("NOT_ENABLED\0NO_FILE_SYSTEM\0MKFS_ABORTED\0TIMEOUT\0LOCKED\0")
		_T("NOT_ENOUGH_CORE\0TOO_MANY_OPEN_FILES\0");
	FRESULT i;

	for (i = 0; i != rc && *p; i++) {
		while(*p++) ;
	}
	_tprintf(_T("rc=%u FR_%s\n"), (UINT)rc, p);
}



BOOL set_console_size (
	HANDLE hcon,
	int width,
	int height,
	int bline
)
{
	COORD dim = {width, bline};
	SMALL_RECT rect = {0, 0, width - 1, height - 1};


	if (SetConsoleScreenBufferSize(hCon, dim) && 
		SetConsoleWindowInfo(hCon, TRUE, &rect) ) return TRUE;

	return FALSE;
}



void get_line (TCHAR *buff, int len)
{
#ifdef UNICODE
	TCHAR c;
	int idx = 0;
	DWORD dw;


	for (;;) {
		ReadConsole(hKey, &c, 1, &dw, NULL);
		if (c == '\r') break;
		if ((c == '\b') && idx) {
			idx--;
		}
		if ((c >= ' ') && (idx < len - 1)) {
				buff[idx++] = c;
		}
	}
	buff[idx] = 0;
#else
	_getts(buff);
#endif
}




/*-----------------------------------------------------------------------*/
/* Main                                                                  */


int _tmain (int argc, TCHAR *argv[])
{
	TCHAR *ptr, *ptr2, pool[300];
	long p1, p2, p3;
	BYTE *buf;
	UINT s1, s2, cnt;
	WORD w;
	DWORD dw, ofs = 0, sect = 0, drv = 0;
	static const BYTE ft[] = {0, 12, 16, 32};
	FRESULT res;
	FATFS *fs;				/* Pointer to file system object */
	DIR dir;				/* Directory object */
	FIL file[2];			/* File objects */


	hKey = GetStdHandle(STD_INPUT_HANDLE);
	hCon = GetStdHandle(STD_OUTPUT_HANDLE);
	set_console_size(hCon, 100, 35, 500);

	if (GetConsoleCP() != _CODE_PAGE) {
		if (!SetConsoleCP(_CODE_PAGE) || !SetConsoleOutputCP(_CODE_PAGE))
			_tprintf(_T("Error: Failed to change the code page.\n"));
	}

	_tprintf(_T("FatFs module test monitor (LFN:%s, CP:%u/%s)\n\n"),
			_USE_LFN ? _T("Enabled") : _T("Disabled"),
			_CODE_PAGE,
			_LFN_UNICODE ? _T("Unicode") : _T("ANSI"));

	if (!assign_drives(PHY_DRV_START, PHY_DRV_END)) {
		_tprintf(_T("\nUnable to access physical drive.\n"));
		Sleep(2000);
		return 2;
	}

#if _USE_LFN
	Finfo.lfname = Lfname;
	Finfo.lfsize = sizeof(Lfname);
#endif

	for (;;) {
		_tprintf(_T(">"));
		ptr = Line;
		get_line(ptr, 256);

		switch (*ptr++) {

		case 'q' :	/* Exit program */
			return 0;

		case 'T' :
			while (*ptr == ' ') ptr++;

			// Quick test space

			break;

		case 'd' :
			switch (*ptr++) {
			case 'd' :	/* dd [<pd#> <sect>] - Dump a secrtor */
				if (!xatoi(&ptr, &p1)) p1 = drv;
				if (!xatoi(&ptr, &p2)) p2 = sect;
				res = disk_read((BYTE)p1, Buff, p2, 1);
				sect = p2 + 1; drv = p1;
				if (res) { _tprintf(_T("rc=%d\n"), (WORD)res); break; }
				_tprintf(_T("Drive:%u Sector:%lu\n"), p1, p2);
				if (disk_ioctl((BYTE)p1, GET_SECTOR_SIZE, &w) != RES_OK) break;
				for (buf = Buff, ofs = 0; ofs < w; buf += 16, ofs += 16)
					put_dump(buf, ofs, 16);
				break;

			case 'i' :	/* di <pd#> - Initialize physical drive */
				if (!xatoi(&ptr, &p1)) break;
				res = disk_initialize((BYTE)p1);
				_tprintf(_T("rc=%d\n"), res);
				if (disk_ioctl((BYTE)p1, GET_SECTOR_SIZE, &w) == RES_OK)
					_tprintf(_T("Sector size = %u\n"), w);
				if (disk_ioctl((BYTE)p1, GET_SECTOR_COUNT, &dw) == RES_OK)
					_tprintf(_T("Number of sectors = %u\n"), dw);
				break;
			}
			break;

		case 'b' :
			switch (*ptr++) {
			case 'd' :	/* bd <ofs> - Dump Buff[] */
				if (!xatoi(&ptr, &p1)) break;
				for (buf = &Buff[p1], ofs = p1, cnt = 32; cnt; cnt--, buf += 16, ofs += 16)
					put_dump(buf, ofs, 16);
				break;

			case 'e' :	/* be <ofs> [<data>] ... - Edit Buff[] */
				if (!xatoi(&ptr, &p1)) break;
				if (xatoi(&ptr, &p2)) {
					do {
						Buff[p1++] = (BYTE)p2;
					} while (xatoi(&ptr, &p2));
					break;
				}
				for (;;) {
					_tprintf(_T("%04X %02X-"), (WORD)(p1), (WORD)Buff[p1]);
					_getts(ptr = Line);
					if (*ptr == '.') break;
					if (*ptr < ' ') { p1++; continue; }
					if (xatoi(&ptr, &p2))
						Buff[p1++] = (BYTE)p2;
					else
						_tprintf(_T("???\n"));
				}
				break;

			case 'r' :	/* br <pd#> <sector> [<n>] - Read disk into Buff[] */
				if (!xatoi(&ptr, &p1)) break;
				if (!xatoi(&ptr, &p2)) break;
				if (!xatoi(&ptr, &p3)) p3 = 1;
				_tprintf(_T("rc=%u\n"), disk_read((BYTE)p1, Buff, p2, (BYTE)p3));
				break;

			case 'w' :	/* bw <sect> [<n>] - Write Buff[] into disk */
				if (!xatoi(&ptr, &p1)) break;
				if (!xatoi(&ptr, &p2)) break;
				if (!xatoi(&ptr, &p3)) p3 = 1;
				_tprintf(_T("rc=%u\n"), disk_write((BYTE)p1, Buff, p2, (BYTE)p3));
				break;

			case 'f' :	/* bf <n> - Fill Buff[] */
				if (!xatoi(&ptr, &p1)) break;
				memset(Buff, (BYTE)p1, sizeof(Buff));
				break;

			}
			break;

		case 'f' :
			switch (*ptr++) {

			case 'i' :	/* fi <ld#> - Force initialized the logical drive */
				if (!xatoi(&ptr, &p1)) break;
				put_rc(f_mount((BYTE)p1, &FatFs[p1]));
				break;

			case 's' :	/* fs [<path>] - Show logical drive status */
				while (*ptr == ' ') ptr++;
#if _FS_READONLY
				res = f_opendir(&dir, ptr);
#else
				res = f_getfree(ptr, (DWORD*)&p1, &fs);
#endif
				if (res) { put_rc(res); break; }
				_tprintf(_T("FAT type = FAT%u\nNumber of FATs = %u\n"), ft[fs->fs_type & 3], fs->n_fats);
				_tprintf(_T("Cluster size = %u * %u = %lu\n"),
#if _MAX_SS != 512
					fs->ssize, fs->csize, (DWORD)fs->csize * fs->ssize);
#else
					512, fs->csize, (DWORD)fs->csize * fs->s_size);
#endif
				if (fs->fs_type != FS_FAT32) _tprintf(_T("Root DIR entries = %u\n"), fs->n_rootdir);
				_tprintf(_T("Sectors/FAT = %lu\nNumber of clusters = %lu\nFAT start sector = %lu\nDIR start %s = %lu\nData start sector = %lu\n\n..."),
					fs->fsize, fs->n_fatent - 2, fs->fatbase, fs->fs_type == FS_FAT32 ? "cluster" : "sector", fs->dirbase, fs->database);
				acc_size = acc_files = acc_dirs = 0;
				res = scan_files(ptr);
				if (res) { put_rc(res); break; }
				p2 = (fs->n_fatent - 2) * fs->csize;
				p3 = p1 * fs->csize;
#if _MAX_SS == 512
				p2 /= 2;
				p3 /= 2;
#else
				p2 *= fs->ssize / 512;
				p3 *= fs->ssize / 512;
#endif
				_tprintf(_T("\r%u files, %I64u bytes.\n%u folders.\n%lu KB total disk space.\n"),
						acc_files, acc_size, acc_dirs, p2);
#if !FS_READONLY
				_tprintf(_T("%lu KB available.\n"), p3);
#endif
				break;

			case 'l' :	/* fl [<path>] - Directory listing */
				while (*ptr == ' ') ptr++;
				res = f_opendir(&dir, ptr);
				if (res) { put_rc(res); break; }
				acc_size = s1 = s2 = 0;
				for(;;) {
					res = f_readdir(&dir, &Finfo);
					if ((res != FR_OK) || !Finfo.fname[0]) break;
					if (Finfo.fattrib & AM_DIR) {
						s2++;
					} else {
						s1++; acc_size += Finfo.fsize;
					}
					_tprintf(_T("%c%c%c%c%c %u/%02u/%02u %02u:%02u %9lu  "),
							(Finfo.fattrib & AM_DIR) ? 'D' : '-',
							(Finfo.fattrib & AM_RDO) ? 'R' : '-',
							(Finfo.fattrib & AM_HID) ? 'H' : '-',
							(Finfo.fattrib & AM_SYS) ? 'S' : '-',
							(Finfo.fattrib & AM_ARC) ? 'A' : '-',
							(Finfo.fdate >> 9) + 1980, (Finfo.fdate >> 5) & 15, Finfo.fdate & 31,
							(Finfo.ftime >> 11), (Finfo.ftime >> 5) & 63, Finfo.fsize);
					_tcscpy(pool, Finfo.fname);
#if _USE_LFN
					for (p2 = _tcslen(Finfo.fname); p2 < 14; p2++)
						_tcscat(pool, _T(" "));
					_tcscat(pool, Lfname);
#endif
					_tcscat(pool, _T("\n"));
					WriteConsole(hCon, pool, _tcslen(pool), &p1, NULL);
				}
				_tprintf(_T("%4u File(s),%10I64u bytes total\n%4u Dir(s)"), s1, acc_size, s2);
				if (f_getfree(ptr, (DWORD*)&p1, &fs) == FR_OK)
					_tprintf(_T(", %10lu bytes free\n"), p1 * fs->csize * 512);
				break;

			case 'o' :	/* fo <mode> <file> - Open a file */
				if (!xatoi(&ptr, &p1)) break;
				while (*ptr == ' ') ptr++;
				put_rc(f_open(&file[0], ptr, (BYTE)p1));
				break;

			case 'c' :	/* fc - Close a file */
				put_rc(f_close(&file[0]));
				break;

			case 'r' :	/* fr <len> - read file */
				if (!xatoi(&ptr, &p1)) break;
				p2 =0;
				while (p1) {
					if ((UINT)p1 >= sizeof(Buff)) {
						cnt = sizeof(Buff); p1 -= sizeof(Buff);
					} else {
						cnt = p1; p1 = 0;
					}
					res = f_read(&file[0], Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					p2 += s2;
					if (cnt != s2) break;
				}
				_tprintf(_T("%lu bytes read.\n"), p2);
				break;

			case 'd' :	/* fd <len> - read and dump file from current fp */
				if (!xatoi(&ptr, &p1)) p1 = 128;
				ofs = file[0].fptr;
				while (p1) {
					if ((UINT)p1 >= 16) { cnt = 16; p1 -= 16; }
					else 				{ cnt = p1; p1 = 0; }
					res = f_read(&file[0], Buff, cnt, &cnt);
					if (res != FR_OK) { put_rc(res); break; }
					if (!cnt) break;
					put_dump(Buff, ofs, cnt);
					ofs += 16;
				}
				break;

			case 'e' :	/* fe <ofs> - Seek file pointer */
				if (!xatoi(&ptr, &p1)) break;
				res = f_lseek(&file[0], p1);
				put_rc(res);
				if (res == FR_OK)
					_tprintf(_T("fptr = %lu(0x%lX)\n"), file[0].fptr, file[0].fptr);
				break;
#if _USE_FASTSEEK
			case 'E' :	/* fE - Enable fast seek and initialize cluster link map table */
				file[0].cltbl = seektbl;			/* Enable fast seek (set address of buffer) */
				seektbl[0] = sizeof(seektbl) / 4;	/* Buffer size */
				res = f_lseek(&file[0], CREATE_LINKMAP);	/* Create link map table */
				put_rc(res);
				if (res == FR_OK) {
					for (p1 = 1, p2 = 0; seektbl[p1]; p2 += seektbl[p1], p1 += 2) ;
					p1 /= 2;
					_tprintf(_T("%d clusters, "), p2);
					_tprintf((p1 > 1) ? _T("fragmented in %d.\n") : _T("contiguous.\n"), p1);
				}
				break;
#endif
#if !_FS_READONLY
			case 'w' :	/* fw <len> <val> - write file */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2)) break;
				memset(Buff, (BYTE)p2, sizeof(Buff));
				p2 = 0;
				while (p1) {
					if ((UINT)p1 >= sizeof(Buff)) { cnt = sizeof(Buff); p1 -= sizeof(Buff); }
					else 				  { cnt = p1; p1 = 0; }
					res = f_write(&file[0], Buff, cnt, &s2);
					if (res != FR_OK) { put_rc(res); break; }
					p2 += s2;
					if (cnt != s2) break;
				}
				_tprintf(_T("%lu bytes written.\n"), p2);
				break;

			case 'v' :	/* fv - Truncate file */
				put_rc(f_truncate(&file[0]));
				break;

			case 'n' :	/* fn <name> <new_name> - Change file/dir name */
				while (*ptr == ' ') ptr++;
				ptr2 = _tcschr(ptr, ' ');
				if (!ptr2) break;
				*ptr2++ = 0;
				while (*ptr2 == ' ') ptr2++;
				put_rc(f_rename(ptr, ptr2));
				break;

			case 'u' :	/* fu <name> - Unlink a file/dir */
				while (*ptr == ' ') ptr++;
				put_rc(f_unlink(ptr));
				break;

			case 'k' :	/* fk <name> - Create a directory */
				while (*ptr == ' ') ptr++;
				put_rc(f_mkdir(ptr));
				break;

			case 'a' :	/* fa <atrr> <mask> <name> - Change file/dir attribute */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2)) break;
				while (*ptr == ' ') ptr++;
				put_rc(f_chmod(ptr, (BYTE)p1, (BYTE)p2));
				break;

			case 't' :	/* ft <year> <month> <day> <hour> <min> <sec> <name> - Change timestamp of a file/dir */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2) || !xatoi(&ptr, &p3)) break;
				Finfo.fdate = (WORD)(((p1 - 1980) << 9) | ((p2 & 15) << 5) | (p3 & 31));
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2) || !xatoi(&ptr, &p3)) break;
				Finfo.ftime = (WORD)(((p1 & 31) << 11) | ((p2 & 63) << 5) | ((p3 >> 1) & 31));
				while (_USE_LFN && *ptr == ' ') ptr++;
				put_rc(f_utime(ptr, &Finfo));
				break;

			case 'x' : /* fx <src_name> <dst_name> - Copy a file */
				while (*ptr == ' ') ptr++;
				ptr2 = _tcschr(ptr, ' ');
				if (!ptr2) break;
				*ptr2++ = 0;
				while (*ptr2 == ' ') ptr2++;
				_tprintf(_T("Opening \"%s\""), ptr);
				res = f_open(&file[0], ptr, FA_OPEN_EXISTING | FA_READ);
				_tprintf(_T("\n"));
				if (res) {
					put_rc(res);
					break;
				}
				while (*ptr2 == ' ') ptr2++;
				_tprintf(_T("Creating \"%s\""), ptr2);
				res = f_open(&file[1], ptr2, FA_CREATE_ALWAYS | FA_WRITE);
				_tprintf(_T("\n"));
				if (res) {
					put_rc(res);
					f_close(&file[0]);
					break;
				}
				_tprintf(_T("Copying..."));
				p1 = 0;
				for (;;) {
					res = f_read(&file[0], Buff, sizeof(Buff), &s1);
					if (res || s1 == 0) break;   /* error or eof */
					res = f_write(&file[1], Buff, s1, &s2);
					p1 += s2;
					if (res || s2 < s1) break;   /* error or disk full */
				}
				_tprintf(_T("\n"));
				if (res) put_rc(res);
				f_close(&file[0]);
				f_close(&file[1]);
				_tprintf(_T("%lu bytes copied.\n"), p1);
				break;
#if _USE_MKFS
			case 'm' :	/* fm <ld#> <partition rule> <cluster size> - Create file system */
				if (!xatoi(&ptr, &p1) || !xatoi(&ptr, &p2) || !xatoi(&ptr, &p3)) break;
				_tprintf(_T("The drive will be formatted. Are you sure? (Y/n)="));
				_fgetts(ptr, 256, stdin);
				if (*ptr != 'Y') break;
				put_rc(f_mkfs((BYTE)p1, (BYTE)p2, (UINT)p3));
				break;
#endif
#endif
#if _FS_RPATH
			case 'g' :	/* fg <path> - Change current directory */
				while (*ptr == ' ') ptr++;
				put_rc(f_chdir(ptr));
				break;

			case 'j' :	/* fj <ld#> - Change current drive */
				if (xatoi(&ptr, &p1)) {
					put_rc(f_chdrive((BYTE)p1));
				}
				break;
#endif
			}
			break;

		case '?':		/* Show usage */
			_tprintf(
				_T("dd [<pd#> <sect>] - Dump a secrtor\n")
				_T("di <pd#> - Initialize disk\n")
				_T("ds <pd#> - Show disk status\n")
				_T("\n")
				_T("bd <ofs> - Dump working buffer\n")
				_T("be <ofs> [<data>] ... - Edit working buffer\n")
				_T("br <pd#> <sect> [<num>] - Read disk into working buffer\n")
				_T("bw <pd#> <sect> [<num>] - Write working buffer into disk\n")
				_T("bf <val> - Fill working buffer\n")
				_T("\n")
				_T("fi <ld#> - Force initialized the volume\n")
				_T("fs [<path>] - Show volume status\n")
				_T("fl [<path>] - Show a directory\n")
				_T("fo <mode> <file> - Open a file\n")
				_T("fc - Close the file\n")
				_T("fe <ofs> - Move fp in normal seek\n")
				_T("fE <ofs> - Move fp in fast seek or Create link table\n")
				_T("fd <len> - Read and dump the file\n")
				_T("fr <len> - Read the file\n")
				_T("fw <len> <val> - Write to the file\n")
				_T("fn <object name> <new name> - Rename an object\n")
				_T("fu <object name> - Unlink an object\n")
				_T("fv - Truncate the file at current fp\n")
				_T("fk <dir name> - Create a directory\n")
				_T("fa <atrr> <mask> <object name> - Change object attribute\n")
				_T("ft <year> <month> <day> <hour> <min> <sec> <object name> - Change timestamp of an object\n")
				_T("fx <src file> <dst file> - Copy a file\n")
				_T("fg <path> - Change current directory\n")
				_T("fj <ld#> - Change current drive\n")
				_T("fm <ld#> <rule> <cluster size> - Create file system\n")
				_T("\n")
			);

		}
	}

}


