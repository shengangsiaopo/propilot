// MESSAGE IMAGE_TRIGGERED PACKING

#define MAVLINK_MSG_ID_IMAGE_TRIGGERED 101
#define MAVLINK_MSG_101_LEN 40

typedef struct __mavlink_image_triggered_t 
{
	uint64_t timestamp; ///< Timestamp
	uint32_t seq; ///< IMU seq
	float roll; ///< Roll angle in rad
	float pitch; ///< Pitch angle in rad
	float yaw; ///< Yaw angle in rad
	float local_z; ///< Local frame Z coordinate (height over ground)
	float lat; ///< GPS X coordinate
	float lon; ///< GPS Y coordinate
	float alt; ///< Global frame altitude
} mavlink_image_triggered_t;

//#if sizeof(mavlink_image_triggered_t) != 40 // sadly this fails 
//#warning struct and size do not match
//#endif


/**
 * @brief Pack a image_triggered message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 *
 * @param timestamp Timestamp
 * @param seq IMU seq
 * @param roll Roll angle in rad
 * @param pitch Pitch angle in rad
 * @param yaw Yaw angle in rad
 * @param local_z Local frame Z coordinate (height over ground)
 * @param lat GPS X coordinate
 * @param lon GPS Y coordinate
 * @param alt Global frame altitude
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_image_triggered_pack(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, uint64_t timestamp, uint32_t seq, float roll, float pitch, float yaw, float local_z, float lat, float lon, float alt)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	msg->msgid = MAVLINK_MSG_ID_IMAGE_TRIGGERED;

	p->timestamp = timestamp; // uint64_t:Timestamp
	p->seq = seq; // uint32_t:IMU seq
	p->roll = roll; // float:Roll angle in rad
	p->pitch = pitch; // float:Pitch angle in rad
	p->yaw = yaw; // float:Yaw angle in rad
	p->local_z = local_z; // float:Local frame Z coordinate (height over ground)
	p->lat = lat; // float:GPS X coordinate
	p->lon = lon; // float:GPS Y coordinate
	p->alt = alt; // float:Global frame altitude

	return mavlink_finalize_message(msg, system_id, component_id, sizeof(mavlink_image_triggered_t));
}

/**
 * @brief Pack a image_triggered message
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param chan The MAVLink channel this message was sent over
 * @param msg The MAVLink message to compress the data into
 * @param timestamp Timestamp
 * @param seq IMU seq
 * @param roll Roll angle in rad
 * @param pitch Pitch angle in rad
 * @param yaw Yaw angle in rad
 * @param local_z Local frame Z coordinate (height over ground)
 * @param lat GPS X coordinate
 * @param lon GPS Y coordinate
 * @param alt Global frame altitude
 * @return length of the message in bytes (excluding serial stream start sign)
 */
static inline uint16_t mavlink_msg_image_triggered_pack_chan(uint8_t system_id, uint8_t component_id, uint8_t chan, mavlink_message_t* msg, uint64_t timestamp, uint32_t seq, float roll, float pitch, float yaw, float local_z, float lat, float lon, float alt)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	msg->msgid = MAVLINK_MSG_ID_IMAGE_TRIGGERED;

	p->timestamp = timestamp; // uint64_t:Timestamp
	p->seq = seq; // uint32_t:IMU seq
	p->roll = roll; // float:Roll angle in rad
	p->pitch = pitch; // float:Pitch angle in rad
	p->yaw = yaw; // float:Yaw angle in rad
	p->local_z = local_z; // float:Local frame Z coordinate (height over ground)
	p->lat = lat; // float:GPS X coordinate
	p->lon = lon; // float:GPS Y coordinate
	p->alt = alt; // float:Global frame altitude

	return mavlink_finalize_message_chan(msg, system_id, component_id, chan, sizeof(mavlink_image_triggered_t));
}

/**
 * @brief Encode a image_triggered struct into a message
 *
 * @param system_id ID of this system
 * @param component_id ID of this component (e.g. 200 for IMU)
 * @param msg The MAVLink message to compress the data into
 * @param image_triggered C-struct to read the message contents from
 */
static inline uint16_t mavlink_msg_image_triggered_encode(uint8_t system_id, uint8_t component_id, mavlink_message_t* msg, const mavlink_image_triggered_t* image_triggered)
{
	return mavlink_msg_image_triggered_pack(system_id, component_id, msg, image_triggered->timestamp, image_triggered->seq, image_triggered->roll, image_triggered->pitch, image_triggered->yaw, image_triggered->local_z, image_triggered->lat, image_triggered->lon, image_triggered->alt);
}

/**
 * @brief Send a image_triggered message
 * @param chan MAVLink channel to send the message
 *
 * @param timestamp Timestamp
 * @param seq IMU seq
 * @param roll Roll angle in rad
 * @param pitch Pitch angle in rad
 * @param yaw Yaw angle in rad
 * @param local_z Local frame Z coordinate (height over ground)
 * @param lat GPS X coordinate
 * @param lon GPS Y coordinate
 * @param alt Global frame altitude
 */
#ifdef MAVLINK_USE_CONVENIENCE_FUNCTIONS

static inline void mavlink_msg_image_triggered_send(mavlink_channel_t chan, uint64_t timestamp, uint32_t seq, float roll, float pitch, float yaw, float local_z, float lat, float lon, float alt)
{
	mavlink_message_t msg;
	uint16_t checksum;
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg.payload[0];

	msg.msgid = MAVLINK_MSG_ID_IMAGE_TRIGGERED;
	msg.len = sizeof(mavlink_image_triggered_t);
	p->timestamp = timestamp; // uint64_t:Timestamp
	p->seq = seq; // uint32_t:IMU seq
	p->roll = roll; // float:Roll angle in rad
	p->pitch = pitch; // float:Pitch angle in rad
	p->yaw = yaw; // float:Yaw angle in rad
	p->local_z = local_z; // float:Local frame Z coordinate (height over ground)
	p->lat = lat; // float:GPS X coordinate
	p->lon = lon; // float:GPS Y coordinate
	p->alt = alt; // float:Global frame altitude

	msg.sysid = mavlink_system.sysid;
	msg.compid = mavlink_system.compid;
	msg.seq = mavlink_get_channel_status(chan)->current_tx_seq;
	mavlink_get_channel_status(chan)->current_tx_seq = mavlink_get_channel_status(chan)->current_tx_seq+1;
	checksum = crc_calculate_msg(&msg, msg.len + MAVLINK_CORE_HEADER_LEN);
	msg.ck_a = (uint8_t)(checksum & 0xFF); ///< High byte
	msg.ck_b = (uint8_t)(checksum >> 8); ///< Low byte

	mavlink_send_uart(chan, &msg);
}

#endif
// MESSAGE IMAGE_TRIGGERED UNPACKING

/**
 * @brief Get field timestamp from image_triggered message
 *
 * @return Timestamp
 */
static inline uint64_t mavlink_msg_image_triggered_get_timestamp(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (uint64_t)(p->timestamp);
}

/**
 * @brief Get field seq from image_triggered message
 *
 * @return IMU seq
 */
static inline uint32_t mavlink_msg_image_triggered_get_seq(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (uint32_t)(p->seq);
}

/**
 * @brief Get field roll from image_triggered message
 *
 * @return Roll angle in rad
 */
static inline float mavlink_msg_image_triggered_get_roll(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->roll);
}

/**
 * @brief Get field pitch from image_triggered message
 *
 * @return Pitch angle in rad
 */
static inline float mavlink_msg_image_triggered_get_pitch(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->pitch);
}

/**
 * @brief Get field yaw from image_triggered message
 *
 * @return Yaw angle in rad
 */
static inline float mavlink_msg_image_triggered_get_yaw(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->yaw);
}

/**
 * @brief Get field local_z from image_triggered message
 *
 * @return Local frame Z coordinate (height over ground)
 */
static inline float mavlink_msg_image_triggered_get_local_z(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->local_z);
}

/**
 * @brief Get field lat from image_triggered message
 *
 * @return GPS X coordinate
 */
static inline float mavlink_msg_image_triggered_get_lat(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->lat);
}

/**
 * @brief Get field lon from image_triggered message
 *
 * @return GPS Y coordinate
 */
static inline float mavlink_msg_image_triggered_get_lon(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->lon);
}

/**
 * @brief Get field alt from image_triggered message
 *
 * @return Global frame altitude
 */
static inline float mavlink_msg_image_triggered_get_alt(const mavlink_message_t* msg)
{
	mavlink_image_triggered_t *p = (mavlink_image_triggered_t *)&msg->payload[0];
	return (float)(p->alt);
}

/**
 * @brief Decode a image_triggered message into a struct
 *
 * @param msg The message to decode
 * @param image_triggered C-struct to decode the message contents into
 */
static inline void mavlink_msg_image_triggered_decode(const mavlink_message_t* msg, mavlink_image_triggered_t* image_triggered)
{
	memcpy( image_triggered, msg->payload, sizeof(mavlink_image_triggered_t));
}
