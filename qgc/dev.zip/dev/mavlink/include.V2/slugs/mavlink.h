/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Thursday, December 2 2010, 10:44 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "slugs.h"

#endif
